(function(){
'use strict';
angular.module('hash').constant('configuration',{
	
});
})();