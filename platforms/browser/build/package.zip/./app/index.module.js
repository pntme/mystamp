(function(){
'use strict';
angular.module('hash', [
	'ionic',
	'ngStorage',
	'ngCordova'
	]);
})();